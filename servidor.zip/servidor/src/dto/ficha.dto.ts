export interface DBFicha {
  id: number;
}
