export interface syncVersionDTO {
  version: string;
}
