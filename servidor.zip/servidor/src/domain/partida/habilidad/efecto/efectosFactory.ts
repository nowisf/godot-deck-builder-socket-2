import { Partida } from "../../partida";
import { Jugador } from "@domain/usuario/jugador";
import { Ficha } from "@domain/ficha/ficha";
import { Casilla } from "../../casilla";
import { Fase } from "../../fases/fase";
import {
  generadorNotificaciones,
  TipoEvento,
} from "../../notificaciones/notificacionesFactory";
import { Habilidad } from "../habilidad";
import { FichaBase } from "@domain/ficha/fichaBase";

export type Efecto = () => void;

export enum TipoEfecto {
  MODIFICAR_ESCENCIA = "MODIFICAR_ESCENCIA",
  APLICAR_ENFRIAMIENTO_HABILIDAD = "APLICAR_ENFRIAMIENTO_HABILIDAD",
  AGREGAR_FICHA = "AGREGAR_FICHA",
  AGREGAR_VISION_EN_RANGO = "AGREGAR_VISION_EN_RANGO",
  AVANZAR_FICHA = "AVANZAR_FICHA",
  DESCONTAR_TODOS_LOS_ENFRIAMIENTOS = "DESCONTAR_TODOS_LOS_ENFRIAMIENTOS",
  AGREGAR_FICHA_INICIO_CAMINO = "AGREGAR_FICHA_INICIO_CAMINO",
  ELIMINAR_HABILIDAD_PENDIENTE_JUGADOR = "ELIMINAR_HABILIDAD_PENDIENTE_JUGADOR",
  QUITAR_VISION_EN_RANGO = "QUITAR_VISION_EN_RANGO",
}

export type EfectoProps =
  | { tipo: TipoEfecto.MODIFICAR_ESCENCIA; cantidad: number; fase?: Fase }
  | {
      tipo: TipoEfecto.APLICAR_ENFRIAMIENTO_HABILIDAD;
      cambio: number;
      fase?: Fase;
    }
  | { tipo: TipoEfecto.AGREGAR_FICHA; fase?: Fase; fichaBase: FichaBase }
  | { tipo: TipoEfecto.AVANZAR_FICHA }
  | { tipo: TipoEfecto.DESCONTAR_TODOS_LOS_ENFRIAMIENTOS }
  | {
      tipo: TipoEfecto.AGREGAR_FICHA_INICIO_CAMINO;
      fichaBase: FichaBase;
      fase?: Fase;
    }
  | { tipo: TipoEfecto.AGREGAR_VISION_EN_RANGO }
  | { tipo: TipoEfecto.QUITAR_VISION_EN_RANGO }
  | { tipo: TipoEfecto.ELIMINAR_HABILIDAD_PENDIENTE_JUGADOR };

export type GeneradorEfectos = {
  [K in EfectoProps["tipo"]]: (
    props: Extract<EfectoProps, { tipo: K }>,
    ctx: EfectoContextos[K]
  ) => Efecto;
};

export interface EfectoContexto {
  partida: Partida;
  jugador?: Jugador;
  ficha?: Ficha;
  habilidad?: Habilidad;
  casilla?: Casilla;
}

export type EfectoContextos = {
  [TipoEfecto.ELIMINAR_HABILIDAD_PENDIENTE_JUGADOR]: {
    jugador: Jugador;
  };

  [TipoEfecto.MODIFICAR_ESCENCIA]: {
    partida: Partida;
    jugador: Jugador;
  };

  [TipoEfecto.AGREGAR_FICHA_INICIO_CAMINO]: {
    partida: Partida;
    jugador: Jugador;
  };

  [TipoEfecto.APLICAR_ENFRIAMIENTO_HABILIDAD]: {
    partida: Partida;
    habilidad: Habilidad;
    jugador: Jugador;
  };

  [TipoEfecto.AGREGAR_FICHA]: {
    partida: Partida;
    jugador: Jugador;
    casilla: Casilla;
  };

  [TipoEfecto.AGREGAR_VISION_EN_RANGO]: {
    partida: Partida;
    ficha: Ficha;
  };
  [TipoEfecto.QUITAR_VISION_EN_RANGO]: {
    partida: Partida;
    ficha: Ficha;
  };

  [TipoEfecto.AVANZAR_FICHA]: {
    partida: Partida;
    ficha: Ficha;
  };

  [TipoEfecto.DESCONTAR_TODOS_LOS_ENFRIAMIENTOS]: {
    partida: Partida;
  };
};

export const generadorEfectos: GeneradorEfectos = {
  [TipoEfecto.ELIMINAR_HABILIDAD_PENDIENTE_JUGADOR]: (_props, ctx) => {
    return () => {
      ctx.jugador.partida.motorWego.agregarEfecto(() => {
        ctx.jugador.habilidadPendiente = null;
      }, Fase.InicioTurno);
    };
  },

  [TipoEfecto.MODIFICAR_ESCENCIA]: (props, ctx) => {
    const { jugador, partida } = ctx;
    const fase = props.fase ?? Fase.Invocaciones;

    return () => {
      partida.motorWego.agregarEfecto(() => {
        jugador.escencia += props.cantidad;
        jugador.agregarNotificacion(
          generadorNotificaciones[TipoEvento.JUGADOR_CAMBIO_ESCENCIA](
            jugador,
            props.cantidad
          )
        );
      }, fase);
    };
  },

  [TipoEfecto.APLICAR_ENFRIAMIENTO_HABILIDAD]: (props, ctx) => {
    const { habilidad, partida } = ctx;
    const fase = props.fase ?? Fase.Invocaciones;

    return () => {
      partida.motorWego.agregarEfecto(() => {
        habilidad.modificarEnfriamiento(props.cambio);
      }, fase);
    };
  },

  //agregar_ficha_spawn sin ctx.ficha?
  //los efectos no deben tener ctx ficha?

  //De momento este efecto solo es llamado por otros efectos,
  // no por habilidades
  [TipoEfecto.AGREGAR_FICHA]: (props, ctx) => {
    const { jugador, casilla, partida } = ctx;
    if (!casilla) return;

    const fase = props.fase ?? Fase.Invocaciones;

    return () => {
      const ficha = new Ficha(props.fichaBase, jugador);
      partida.motorWego.agregarEfecto(() => {
        casilla.agregarFicha(ficha);

        casilla.jugadoresQueVen.forEach((jugador) => {
          const aliada = ficha.amo === jugador;
          jugador.agregarNotificacion(
            generadorNotificaciones[TipoEvento.FICHA_REVELADA](ficha, aliada)
          );
        });

        generadorEfectos[TipoEfecto.AGREGAR_VISION_EN_RANGO](
          { tipo: TipoEfecto.AGREGAR_VISION_EN_RANGO },
          { partida, ficha }
        )();
      }, fase);
    };
  },

  [TipoEfecto.AGREGAR_FICHA_INICIO_CAMINO]: (props, ctx) => {
    const { jugador, partida } = ctx;

    const fase = props.fase ?? Fase.Invocaciones;
    const casilla = partida.getCasillaInicioCamino(jugador.bando);

    return () => {
      partida.motorWego.agregarEfecto(() => {
        const ficha = new Ficha(props.fichaBase, jugador);
        casilla.agregarFicha(ficha);

        casilla.jugadoresQueVen.forEach((jugador) => {
          const aliada = ficha.amo === jugador;
          jugador.agregarNotificacion(
            generadorNotificaciones[TipoEvento.FICHA_REVELADA](ficha, aliada)
          );
        });

        generadorEfectos[TipoEfecto.AGREGAR_VISION_EN_RANGO](
          { tipo: TipoEfecto.AGREGAR_VISION_EN_RANGO },
          { partida, ficha }
        )();
      }, fase);
    };
  },

  [TipoEfecto.AGREGAR_VISION_EN_RANGO]: (_props, ctx) => {
    const { ficha, partida } = ctx;

    const coords = ficha.coords;
    const rango = ficha.stats.distanciaVision;
    const forma = ficha.formaVision;
    const amo = ficha.amo;

    return () => {
      partida.motorWego.agregarEfecto(() => {
        partida.tablero.agregarVisionEnRango(coords, rango, forma, amo);
      }, Fase.CambiosVision);
    };
  },
  [TipoEfecto.QUITAR_VISION_EN_RANGO]: (_props, ctx) => {
    const { ficha, partida } = ctx;

    const coords = ficha.coords;
    const rango = ficha.stats.distanciaVision;
    const forma = ficha.formaVision;
    const amo = ficha.amo;

    return () => {
      partida.motorWego.agregarEfecto(() => {
        partida.tablero.quitarVisionEnRango(coords, rango, forma, amo);
      }, Fase.CambiosVision);
    };
  },

  [TipoEfecto.AVANZAR_FICHA]: (_props, ctx) => {
    const { ficha, partida } = ctx;
    return () => {
      partida.motorWego.agregarEfecto(() => {
        if (!partida.tablero.puedeAvanzar(ficha)) {
          return;
          //Aqui va la victoria?
        }
        const efectoQuitarVicion = generadorEfectos[
          TipoEfecto.QUITAR_VISION_EN_RANGO
        ]({ tipo: TipoEfecto.QUITAR_VISION_EN_RANGO }, { partida, ficha });

        const resultado = partida.tablero.avanzarFicha(ficha);

        if (!resultado) return;

        const { casillaActual, siguiente } = resultado;

        [
          ...new Set([
            ...casillaActual.jugadoresQueVen,
            ...siguiente.jugadoresQueVen,
          ]),
        ].forEach((jugador) => {
          jugador.agregarNotificacion(
            generadorNotificaciones[TipoEvento.FICHA_MOVIDA](
              casillaActual,
              siguiente,
              ficha,
              jugador === ficha.amo
            )
          );
        });
        generadorEfectos[TipoEfecto.AGREGAR_VISION_EN_RANGO](
          { tipo: TipoEfecto.AGREGAR_VISION_EN_RANGO },
          { partida, ficha }
        )();
        efectoQuitarVicion();
      }, Fase.MovimientoNormal);
    };
  },

  [TipoEfecto.DESCONTAR_TODOS_LOS_ENFRIAMIENTOS]: (_props, ctx) => {
    const partida = ctx.partida;

    return () => {
      partida.motorWego.agregarEfecto(() => {
        [
          ...partida.bandoA,
          ...partida.bandoB,
          ...partida.fichasEnJuego,
        ].forEach((habilidoso) => {
          habilidoso.reducirEnfriamientosHabilidades();
        });
      }, Fase.InicioTurno);
    };
  },
};
