import { Coords } from "../coords";
const secuenciaTest: Coords[] = [
  { x: 0, y: 0 },
  { x: 1, y: 0 },
  { x: 2, y: 0 },
];

export { secuenciaTest };
