// añadir omologo a wego
export enum Fase {
  InicioTurno = -1,
  MovimientoRapido = 0,
  Buffs = 1,
  Ataques = 2,
  RetirarMuertos = 3,
  Invocaciones = 4,
  MovimientoNormal = 5,
  CambiosVision = 6,
}

//quiza necesite post ataque post muerte etc
