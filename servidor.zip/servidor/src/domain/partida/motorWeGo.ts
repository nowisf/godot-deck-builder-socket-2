import { Fase } from "./fases/fase";
import { Partida } from "./partida";

export class MotorWego {
  /** Efectos agrupados por fase */
  public efectosPorFase: Record<Fase, Function[]> = {
    [Fase.InicioTurno]: [],
    [Fase.MovimientoRapido]: [],
    [Fase.Buffs]: [],
    [Fase.Ataques]: [],
    [Fase.RetirarMuertos]: [],
    [Fase.Invocaciones]: [],
    [Fase.MovimientoNormal]: [],
    [Fase.CambiosVision]: [],
  };

  constructor(public partida: Partida) {}

  /** Agrega un efecto según su fase */
  agregarEfecto(efecto: Function, fase: Fase) {
    if (this.efectosPorFase[fase] === undefined) {
      throw new Error(`Fase inválida: ${fase}`);
    }
    this.efectosPorFase[fase].push(efecto);
  }

  /** Procesa todas las fases ordenadas */
  procesarFases() {
    const fasesOrdenadas = Object.values(Fase).filter(
      (v) => typeof v === "number"
    ) as Fase[];
    fasesOrdenadas.sort((a, b) => a - b);

    for (const fase of fasesOrdenadas) {
      for (const efecto of this.efectosPorFase[fase]) {
        efecto();
        console.log(`Efecto ejecutado en fase ${Fase[fase]}.`);
      }

      // Limpiar fase tras procesarla
      this.efectosPorFase[fase] = [];
    }
  }
}
