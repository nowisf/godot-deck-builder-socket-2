export type Coords = { x: number; y: number };
