import { FichaBase } from "@domain/ficha/fichaBase";
import { Casilla } from "@domain/partida/casilla";
import { Coords } from "@domain/partida/coords";
import { Habilidad } from "@domain/partida/habilidad/habilidad";
import { Partida } from "@domain/partida/partida";

import { FormaArea } from "@domain/partida/tablero";
import { Jugador } from "@domain/usuario/jugador";

export class Ficha {
  public partida: Partida;
  public casilla: Casilla | null = null;
  public coords: Coords | null = null;
  public stats: Record<string, number> = {};
  public id: string = crypto.randomUUID();
  // public vidaActual: number;
  // public vidaMax: number;

  //vicionDistancia; stat?
  //vicionForma;stat?

  public formaVision: FormaArea = FormaArea.DIAMANTE; //stat?

  public habilidades: Habilidad[] = [];

  constructor(public base: FichaBase, public amo: Jugador) {
    // Copia stats base
    this.stats = { ...base.stats };
    this.partida = amo.partida;

    amo.partida.fichasEnJuego.push(this);

    for (const habilidadBase of base.habilidadesBase) {
      const habilidad = habilidadBase.toHabilidad({
        ficha: this,
        tablero: this.partida.tablero,
        partida: this.partida,
      });

      this.habilidades.push(habilidad);
    }
  }
  reducirEnfriamientosHabilidades() {
    this.habilidades.forEach((habilidad) => {
      habilidad.modificarEnfriamiento(-1);
    });
  }
  toJSON() {
    return {
      id: this.id,
      fichaBaseId: this.base.id,
      amo: this.amo,
      stats: this.stats,
      // vidaActual: this.vidaActual,
      // vidaMax: this.vidaMax,
    };
  }

  modificarStat(nombre: string, valor: number) {
    if (!this.stats[nombre]) {
      this.stats[nombre] = 0;
    }
    this.stats[nombre] += valor;
  }
}
